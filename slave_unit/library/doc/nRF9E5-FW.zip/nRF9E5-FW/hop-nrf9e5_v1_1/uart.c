/*= uart.c =========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.08 and 7.09
 *
 * $Revision: 3 $
 *
 *==================================================================================================
*/
#include <Nordic\reg9e5.h>
#include "uart.h"

void InitUart(void)
{
    TH1 = 243;                      // 19200@16MHz (when T1M=1 and SMOD=1)
    CKCON |= 0x10;                  // T1M=1 (/4 timer clock)
    PCON = 0x80;                    // SMOD=1 (double baud rate)
    SCON = 0x52;                    // Serial mode1, enable receiver
    TMOD &= ~0x30;
    TMOD |= 0x20;                   // Timer1 8bit auto reload 
    TR1 = 1;                        // Start timer1
    P0_ALT |= 0x06;                 // Select alternate functions on pins P0.1 and P0.2
    P0_DIR |= 0x02;                 // P0.1 (RxD) is input 
    ES = 0;
}

void PutChar(char c)
{
    TI = 0;
    SBUF = c;
    while(!TI)
        ;
}

unsigned char GetChar(void)
{
    while(!RI)
        ;
    RI = 0;
    return SBUF;
}
