/*= lm35.h =========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 3 $
 *
 *==================================================================================================
*/
#ifndef __HOPPING_LM35_H__
#define __HOPPING_LM35_H__

void InitADC(void);
unsigned int ReadLM35(void);

#endif
