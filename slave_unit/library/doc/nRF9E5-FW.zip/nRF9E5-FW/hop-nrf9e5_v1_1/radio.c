/*= radio.c ========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *  Packet format:
 *
 *  [4 byte address][1 byte msg ID][0-25 bytes msg data][16 bit CRC]
 *
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.08
 *
 * $Revision: 6 $
 *
 *==================================================================================================
*/
#include <Nordic\reg9e5.h>
#include "util.h"
#include "radio.h"

#define HFREQ 0     // 0=433MHz, 1=868/915MHz
#define POWER 3     // 0=min power...3 = max power

const unsigned char code rnd_tab[256] =
{
    // This table contains four each of the numbers 2 to 65 (0x02-0x41) randomly distributed.
    // If you need longer random cycles than this you could use an 8-bit pseudo random generator
    // and use it to index this table.
    0x28, 0x29, 0x38, 0x07, 0x19, 0x17, 0x2F, 0x1F, 0x14, 0x16, 0x1F, 0x06, 0x38, 0x1B, 0x3B, 0x33,
    0x33, 0x2F, 0x37, 0x1A, 0x32, 0x15, 0x19, 0x34, 0x1B, 0x2D, 0x13, 0x02, 0x3F, 0x18, 0x10, 0x10,
    0x0A, 0x1D, 0x0D, 0x37, 0x3D, 0x0B, 0x2A, 0x25, 0x1F, 0x20, 0x41, 0x21, 0x2F, 0x2A, 0x36, 0x09,
    0x1C, 0x2C, 0x0F, 0x1E, 0x39, 0x03, 0x06, 0x03, 0x2B, 0x0A, 0x1D, 0x02, 0x24, 0x3A, 0x32, 0x10,
    0x16, 0x16, 0x13, 0x12, 0x20, 0x06, 0x13, 0x1F, 0x0D, 0x41, 0x1E, 0x08, 0x3D, 0x31, 0x09, 0x16,
    0x23, 0x12, 0x2D, 0x12, 0x31, 0x1C, 0x36, 0x0B, 0x11, 0x21, 0x37, 0x13, 0x38, 0x41, 0x0B, 0x32,
    0x1B, 0x33, 0x20, 0x29, 0x0E, 0x05, 0x41, 0x1E, 0x05, 0x0C, 0x38, 0x1D, 0x20, 0x2F, 0x29, 0x39,
    0x3D, 0x04, 0x26, 0x10, 0x12, 0x36, 0x3B, 0x08, 0x3D, 0x3C, 0x1A, 0x24, 0x08, 0x07, 0x35, 0x15,
    0x2A, 0x40, 0x2C, 0x11, 0x31, 0x28, 0x2A, 0x1E, 0x02, 0x07, 0x19, 0x32, 0x28, 0x39, 0x1A, 0x28,
    0x19, 0x22, 0x03, 0x21, 0x39, 0x09, 0x03, 0x0F, 0x3E, 0x2D, 0x0D, 0x37, 0x18, 0x3E, 0x09, 0x25,
    0x26, 0x11, 0x36, 0x1A, 0x18, 0x25, 0x3E, 0x29, 0x08, 0x3C, 0x2B, 0x33, 0x02, 0x0A, 0x05, 0x0A,
    0x1C, 0x2C, 0x07, 0x23, 0x3E, 0x1B, 0x3F, 0x2E, 0x3B, 0x31, 0x2B, 0x24, 0x35, 0x26, 0x1D, 0x2E,
    0x11, 0x3C, 0x15, 0x2B, 0x15, 0x24, 0x2C, 0x27, 0x0D, 0x34, 0x14, 0x23, 0x21, 0x04, 0x3A, 0x27,
    0x0F, 0x40, 0x27, 0x0B, 0x30, 0x2E, 0x17, 0x25, 0x3C, 0x34, 0x40, 0x34, 0x0C, 0x2D, 0x30, 0x18,
    0x40, 0x0F, 0x22, 0x26, 0x27, 0x3F, 0x30, 0x22, 0x30, 0x3F, 0x23, 0x14, 0x3A, 0x14, 0x3B, 0x0C,
    0x06, 0x04, 0x05, 0x3A, 0x35, 0x0E, 0x0E, 0x0C, 0x17, 0x1C, 0x35, 0x0E, 0x04, 0x2E, 0x17, 0x22
};

static unsigned char seq, hopIdx, nBytes;
static unsigned rxTout, txTout;

static void SwitchChannel(void)
{
    RACSN = 0;
    SpiReadWrite(CC | (POWER << 2) | (HFREQ << 1));
    SpiReadWrite(rnd_tab[hopIdx]);
    RACSN = 1;
}

static void TransmitBytes(unsigned char *pBuf, unsigned char msgid)
{
    // Transmit one packet with the format specified in the header of this file:
    unsigned char i;

    SwitchChannel();
    TXEN = 1;
    RACSN = 0;
    SpiReadWrite(WTP);
    SpiReadWrite(msgid);
    for (i=0;i<nBytes;i++)
    {
        SpiReadWrite(pBuf[i]);
    }
    RACSN = 1;
    TRX_CE = 1;
    Delay100us(1);
    TRX_CE = 0;
    while(DR == 0)
        ;
}

static void SendAck(unsigned char msgid)
{
    // Send a one byte acknowledge
    SwitchChannel();
    TXEN = 1;
    RACSN = 0;
    SpiReadWrite(WTP);
    SpiReadWrite(msgid);
    RACSN = 1;
    TRX_CE = 1;
    Delay100us(1);
    TRX_CE = 0;
    while(DR == 0)
        ;
}

static unsigned char ReceiveBytes(unsigned char *pBuf)
{
    unsigned char i, cmd;

    SwitchChannel();
    TXEN = 0;
    TRX_CE = 1;
    ResetTimer(1);
    while(DR == 0)
    {
        if ((rxTout != 0) && (GetTimer(1) > rxTout))
        {
            TRX_CE = 0;
            return 0;
        }
    }
    TRX_CE = 0;
    RACSN = 0;
    SpiReadWrite(RRP);
    cmd = SpiReadWrite(0);
    i = 0;
    while(DR)
    {
        pBuf[i++] = SpiReadWrite(0);
        if (i == nBytes)                        // Play safe
            break;
    }
    RACSN = 1;
    return cmd;
}

static unsigned char WaitAck(void)
{
    unsigned char ack;

    SwitchChannel();
    TXEN = 0;
    TRX_CE = 1;

    ResetTimer(0);
    while(DR == 0)
    {
        if (GetTimer(0) > 2)                    // 3ms time-out
        {
            TRX_CE = 0;
            return 0;
        }
    }
    TRX_CE = 0;
    RACSN = 0;
    SpiReadWrite(RRP);
    ack = SpiReadWrite(0);
    RACSN = 1;    
    return ack;
}

unsigned char TransmitPacket(unsigned char *pBuf)
{
    unsigned int i;
    unsigned char cmdt, cmdr, j;

    seq++;
    cmdt = 0x10 | (seq & 0x0f);
    cmdr = 0;
    ResetTimer(1);
    for(;;)
    {
        for (i=0;i<256;i++)
        {
            // Repeat two times on all channels if no ACK is received
            for (j=0;j<2;j++)
            {
                TransmitBytes(pBuf, cmdt);
                cmdr = WaitAck();
                if ((cmdr != 0) && ((cmdr & 0x0f) == (cmdt & 0x0f)))
                {
                    hopIdx++;
                    return 1;
                }
            }
            hopIdx++;
            if ((txTout != 0) && (GetTimer(1) > txTout))
                return 0;
        }
    }
    return 0;
}

unsigned char ReceivePacket(unsigned char *pBuf)
{
    unsigned char cmd;
    while(1)
    {
        cmd = ReceiveBytes(pBuf);
        if (cmd == 0)
            return 0;
        cmd = (cmd & 0x0f) | 0x20;
        SendAck(cmd);
        hopIdx++;
        if ((cmd & 0x0f) != seq)
        {
            seq = cmd & 0x0f;
            break;
        }
    }
    return 1;
}

void ReceiverTimeout(unsigned tOut)
{
    // Set the receiver timeout in ms.
    // 1ms = min timeout, 65536ms is max, 0 means wait forever
    rxTout = tOut;
}

void TransmitterTimeout(unsigned tOut)
{
    // Set the transmitter timeout in ms.
    // 1ms is min timeout, 65536ms is max, 0 means wait forever
    txTout = tOut;
}

static void InitAddress(unsigned char spiAddr, unsigned char *pAddr)
{
    unsigned char i;
    RACSN = 0;
    SpiReadWrite(spiAddr);
    for(i=0;i<4;i++)
        SpiReadWrite(pAddr[i]);
    RACSN = 1;
}

static void InitCommon(unsigned char nRx, unsigned char nTx)
{
    hopIdx = 0;                                 // Start at index #0 in the channel table above
    RACSN = 0;
    SpiReadWrite(WRC | 0x03);                   // Write to RF config address 3 (RX payload)
    SpiReadWrite(nRx);
    SpiReadWrite(nTx);
    RACSN = 1;
}

void InitReceiver(unsigned char n, unsigned char *pAddr)
{
    seq = 15;
    rxTout = 3000;                              // Default 3s timeout
    nBytes = n;                                 // Number of data bytes (0-25)
    InitCommon(n+1, 1);
    if (pAddr != 0)
        InitAddress(WRC | 0x05, pAddr);         // Configure RX address
}

void InitTransmitter(unsigned char n, unsigned char *pAddr)
{
    seq = 0;
    txTout = 3000;                              // Default 3s timeout
    nBytes = n;                                 // Number of data bytes (0-25)
    InitCommon(1, n+1);
    if (pAddr != 0)
        InitAddress(WTA, pAddr);                // Configure TX address
}
