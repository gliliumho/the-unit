/*= util.c =========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.08 and 7.09
 *
 * $Revision: 2 $
 *
 *==================================================================================================
*/
#include <Nordic\reg9e5.h>
#include "uart.h"
#include "util.h"

const char hex_tab[] = "0123456789ABCDEF";      // ASCII-hex table used by hex-output routines

static volatile unsigned idata timer[2];        // Two utility timers used in radio.c
static volatile unsigned char t0lrel, t0hrel;

void Delay100us(unsigned char n)
{
    unsigned char i;
    while(n--)
        for(i=0;i<35;i++)
            ;
}

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                              // Clear SPI interrupt
    SPI_DATA = b;                               // Move byte to send to SPI data register
    while((EXIF & 0x20) == 0x00)                // Wait until SPI hs finished transmitting
        ;
    return SPI_DATA;
}

void PutString(const char *s)
{
    while(*s != 0)
        PutChar(*s++);
}

void HexOutNib(unsigned char n)
{
    PutChar(hex_tab[n & 0x0f]);
}

void HexOutByte(unsigned char b)
{
    HexOutNib(b >> 4);
    HexOutNib(b & 0x0f);
}

void HexOutWord(unsigned int w)
{
    HexOutByte(w >> 8);
    HexOutByte(w & 0xff);
}

void InitTimer(void)
{
    timer[0] = timer[1] = 0;

    TR0 = 0;
    TMOD &= ~0x03;
    TMOD |= 0x01;                               // mode 1
    CKCON |= 0x08;                              // T0M = 1 (/4 timer clock)
    t0lrel = 0x60;                              // 1KHz tick...
    t0hrel = 0xF0;                              // ... = 65536-16e6/(4*1e3) = F060h
    TF0 = 0;                                    // Clear any pending Timer0 interrupts
    TR0 = 1;                                    // Start Timer0
    ET0 = 1;                                    // Enable Timer0 interrupt
}

void Timer0ISR (void) interrupt 1
{
    TF0 = 0;                                    // Clear Timer0 interrupt
    TH0 = t0hrel;                               // Reload Timer0 high byte
    TL0 = t0lrel;                               // Reload Timer0 low byte
    timer[0]++;                                 // Increment timer[0]
    timer[1]++;                                 // Increment timer[1
}

void ResetTimer(unsigned char n)
{
    ET0 = 0;                                    // Disable Timer0 interrupt
    timer[n & 0x01] = 0;                        // Clear timer[n]
    ET0 = 1;                                    // Enable Timer0 interrupt
}

unsigned GetTimer(unsigned char n)
{
    unsigned tmp;
    ET0 = 0;                                    // Disable Timer0 interrupt
    tmp = timer[n];                             // Clear timer[n]
    ET0 = 1;                                    // Enable Timer0 interrupt
    return tmp;
}
