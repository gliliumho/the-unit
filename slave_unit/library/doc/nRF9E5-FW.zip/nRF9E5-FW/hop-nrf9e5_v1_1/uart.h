/*= uart.h =========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==================================================================================================
*/
#ifndef __HOPPING_UART_H__
#define __HOPPING_UART_H__

void InitUart(void);
void PutChar(char c);
unsigned char GetChar(void);

#endif
