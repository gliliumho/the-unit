/*= lm35.c =========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.08 and 7.09
 *
 * $Revision: 3 $
 *
 *==================================================================================================
*/
#include <Nordic\reg9e5.h>
#include "util.h"
#include "lm35.h"

void InitADC(void)
{
    // Configure and turn on ADC
    RACSN = 0;
    SpiReadWrite(WAC);              // Write to ADC config
    SpiReadWrite(0x35);             // Select AIN3, PWR_UP = 1, VFSEL=0;
    SpiReadWrite(0x0b);             // Set RES_CTRL = 3, Right justified
    RACSN = 1;
}

unsigned int ReadLM35(void)
{
    unsigned char adc0;
    unsigned int adc;

    // Start ADC conversion
    RACSN = 0;
    SpiReadWrite(SAV  | 0x03);
    RACSN = 1;

    // Wait until ADC conversion complete
    while(EOC == 0)
        ;
    // Read Out ADC Value
    RACSN = 0;
    SpiReadWrite(RAD);
    adc0 = SpiReadWrite(NOP);
    adc = SpiReadWrite(NOP);
    RACSN = 1;
    adc <<= 8;
    adc |= adc0;
    return adc;
}
