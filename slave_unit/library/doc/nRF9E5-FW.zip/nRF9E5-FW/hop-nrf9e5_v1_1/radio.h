/*= radio.h ========================================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 3 $
 *
 *==================================================================================================
*/
#ifndef __HOPPING_RADIO_H__
#define __HOPPING_RADIO_H__

unsigned char TransmitPacket(unsigned char *pBuf);
unsigned char ReceivePacket(unsigned char *pBuf);
void ReceiverTimeout(unsigned tOut);
void TransmitterTimeout(unsigned tOut);
void InitReceiver(unsigned char n, unsigned char *pAddr);
void InitTransmitter(unsigned char n, unsigned char *pAddr);

#endif
