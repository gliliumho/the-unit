/*= main.c (nRF9E5 Hopping Demo) ===================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.08 and 7.09
 *
 * $Revision: 5 $
 *
 *==================================================================================================
*/
#include <Nordic\reg9e5.h>
#include "util.h"
#include "uart.h"
#include "radio.h"
#include "lm35.h"

static unsigned char idata buf[4];

void Init(void)
{
    unsigned char cklf;

    SPICLK = 0;                         // Max SPI clock
    SPI_CTRL = 0x02;                    // Connect internal SPI controller to Radio

    // Switch to 16MHz clock:
    RACSN = 0;
    SpiReadWrite(RRC | 0x09);
    cklf = SpiReadWrite(0) | 0x04;
    RACSN = 1;
    RACSN = 0;
    SpiReadWrite(WRC | 0x09);
    SpiReadWrite(cklf); 
    RACSN = 1;

    P0_DIR |= 0x40;                     // P0.6 is input
    P0_DIR &= ~0x30;                    // P0.4 and P0.5 are outputs
    P0 = 0x10;                          // P0.4 = 1 for the rec/tran selection

    InitADC();
    InitTimer();
    EA = 1;
}

void Transmitter(void)
{
    unsigned int temp;

    InitTransmitter(2, 0);              // Use default address for this demo
    while(1)
    {
        temp = ReadLM35();
        buf[0] = temp & 0xff;
        buf[1] = temp >> 8;
        TransmitPacket(buf);
    }
}

void Receiver(void)
{
    unsigned int temp;

    InitReceiver(2, 0);                 // Use default address for this demo
    while(1)
    {
        switch(GetChar())
        {
            case 'I':
                PutString("NRF9E5 Hopping demo!\r\n");
                break;

            case 'L':                   // Read local temperature sensor
                temp = ReadLM35();
                HexOutWord(temp);
                break;

            case 'R':                   // Read remote temperature sensor
                if (ReceivePacket(buf) != 0)
                {
                    HexOutByte(buf[1]);
                    HexOutByte(buf[0]);
                } else
                {
                    HexOutWord(0xffff); // Indicates an error
                }
                break;
        }
    }
}

void main(void)
{
    Init();
    Delay100us(100);
    if (P0 & 0x40)
    {
        InitUart();
        Receiver();
    }
    else
    {
        Transmitter();
    }
}
