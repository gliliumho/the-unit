/*= ex2c-rx.c ==================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   This example should be used together with ex2c-tx.c. One nRF9E5 evaluation
 *   board (receiver) should be programmed with the hex-file generated from
 *   compiling this file and the other evaluation board (transmitter) programmed
 *   with the hex-file generated from compiling ex2c-tx.c.
 *
 *   All switches on the DIP-swith S206 on the receiver must be set to the "on"
 *   position and all switches on the DIP-swith S205 on the transmitter must be
 *   set to the "on" position.
 *
 *   When one of the switched SW1-SW4 on the transmitter is pressed the
 *   corresponding LED on the receiver is turned on.
 *
 *   Please set HFREQ below to a setting that matches the frequency of your
 *   EVBOARD. You also have to set the channel if a frequency other than the
 *   default is needed.
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.09.
 *
 * $Revision: 4 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>

#define HFREQ 0                     // 0=433MHz, 1=868/915MHz

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                  // Clear SPI interrupt
    SPI_DATA = b;                   // Move byte to send to SPI data register
    while((EXIF & 0x20) == 0x00)    // Wait until SPI hs finished transmitting
        ;
    return SPI_DATA;
}


unsigned char ReceivePacket()
{
    unsigned char b;

    TRX_CE = 1;

    while(DR == 0)
        ;
    RACSN = 0;
    SpiReadWrite(RRP);
    b = SpiReadWrite(0);
    RACSN = 1;
    TRX_CE = 0;
    return b;
}

void Receiver(void)
{
    unsigned char b;
    TXEN = 0;
    for(;;)
    {
        b = ReceivePacket();
        P0 = (b >> 1);
    }
}

void Init(void)
{
    unsigned char tmp;

    P0_ALT = 0x00;
    P0_DIR = 0x00;

    SPICLK = 0;                     // Max SPI clock
    SPI_CTRL = 0x02;                // Connect internal SPI controller to Radio

    // Configure Radio:
    RACSN = 0;
    SpiReadWrite(WRC | 0x03);       // Write to RF config address 3 (RX payload)
    SpiReadWrite(0x01);             // One byte RX payload
    SpiReadWrite(0x01);             // One byte TX payload
    RACSN = 1;

    RACSN = 0;
    SpiReadWrite(RRC | 0x01);       // Read RF config address 1
    tmp = SpiReadWrite(0) & 0xf1;   // Clear the power and frequency setting bits
    RACSN = 1;

    RACSN = 0;
    SpiReadWrite(WRC | 0x01);      // Write RF config address 1
    // Change to 433 or 868/915MHz defined by HFREQ above:
    SpiReadWrite(tmp | (HFREQ << 1));
    RACSN = 1;
}

void main(void)
{
    Init();
    Receiver();
}
