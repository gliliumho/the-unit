/*= ex3c.c =====================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   Hello World program (19200 baud).
 *
 *   The functionality is the same as in ex3a.asm.
 *
 * COMPILER:
 *
 *  This program has been tested with Keil V7.09.
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                  // Clear SPI interrupt
    SPI_DATA = b;                   // Move byte to send to SPI data register
    while((EXIF & 0x20) == 0x00)    // Wait until SPI hs finished transmitting
        ;
    return SPI_DATA;
}

void Init(void)
{
    unsigned char cklf;

    TH1 = 243;                      // 19200@16MHz (when T1M=1 and SMOD=1)
    CKCON |= 0x10;                  // T1M=1 (/4 timer clock)
    PCON = 0x80;                    // SMOD=1 (double baud rate)
    SCON = 0x52;                    // Serial mode1, enable receiver
    TMOD = 0x20;                    // Timer1 8bit auto reload 
    TR1 = 1;                        // Start timer1
    P0_ALT |= 0x06;                 // Select alternate functions on pins P0.1 and P0.2
    P0_DIR |= 0x02;                 // P0.1 (RxD) is input

    SPICLK = 0;                     // Max SPI clock
    SPI_CTRL = 0x02;                // Connect internal SPI controller to Radio

    // Switch to 16MHz clock:
    RACSN = 0;
    SpiReadWrite(RRC | 0x09);
    cklf = SpiReadWrite(0) | 0x04;
    RACSN = 1;
    RACSN = 0;
    SpiReadWrite(WRC | 0x09);
    SpiReadWrite(cklf);
    RACSN = 1;
}

void PutChar(char c)
{
    while(!TI)
        ;
    TI = 0;
    SBUF = c;
}

void PutString(const char *s)
{
    while(*s != 0)
        PutChar(*s++);
}

int main(void)
{
    Init();
    PutString("Hello World!\n");
    for (;;)
        ;
    return 0;
}
