/*==============================================================================
 *
 * Copyright (C) 2003-2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND. 
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#ifndef __DS1624_9E5_H__
#define __DS1624_9E5_H__

void DS1624Init(void);
unsigned int DS1624ReadTemperature(unsigned char addr);

#endif
