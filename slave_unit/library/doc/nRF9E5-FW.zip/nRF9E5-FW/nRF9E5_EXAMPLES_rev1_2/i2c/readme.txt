
This example contains an implementation of I2C routines for the nRF9E5 and
shows how to use them to read the temperature from a Dallas Semiconductor
DS1624 Digital Thermometer and Memory. Please read the comments in the header
of each source file for more information.
