/*==============================================================================
 *
 * Copyright (C) 2003-2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#ifndef __I2C_9E5_H__
#define __I2C_9E5_H__

void I2CInit(void);
void I2CStart(void);
void I2CRepStart(void);
void I2CStop(void);
unsigned char I2CWrite(unsigned char b);
unsigned char I2CRead(unsigned char ack);

#endif
