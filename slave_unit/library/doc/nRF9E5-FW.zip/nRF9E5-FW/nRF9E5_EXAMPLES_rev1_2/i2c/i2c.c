/*= i2c.c ======================================================================
 *
 * Copyright (C) 2003-2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   I2C routines. It is assumed that the I2C devices are connected to the
 *   nRF9E5 in this manner:
 *
 *   SDA: P0.7
 *   SCL: P0.5
 *
 *   Both SDA and SCL must have pull-up resistors (10K to 47K) to VDD.
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.07a.
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>
#include "i2c.h"

#define SDA         0x80            // SDA on P0.7
#define SCL         0x20            // SCL on P0.5

#define SDAREL      P0_DIR |= SDA
#define SDALOW      P0_DIR &= ~SDA
#define ISSDAH      (P0 & SDA) == SDA
#define SCLREL      P0_DIR |= SCL
#define SCLLOW      P0_DIR &= ~SCL
#define ISSCLH      (P0 & SCL) == SCL
#define ISSCLL      (P0 & SCL) == 0x00

void I2CInit(void)
{
    SDAREL;
    SCLREL;
    P0 &= ~(SDA | SCL);
}

void I2CStart(void)
{
    SCLREL;
    SDAREL;
    SDALOW;
}

void I2CRepStart(void)
{
    SCLLOW;
    SDAREL;
    SCLREL;
    SDALOW;
}

void I2CStop(void)
{
    SCLLOW;
    SDALOW;
    SCLREL;
    SDAREL;
}

unsigned char I2CWrite(unsigned char b)
{
    unsigned char i;

    for(i=0;i<8;i++)
    {
        SCLLOW;
        if (b & 0x80)
            SDAREL;
        else
            SDALOW;
        SCLREL;
        b <<= 1;
    }
    SCLLOW;
    SDAREL;
    SCLREL;
    while (ISSCLL)
        ;
    if (ISSDAH)
        return 1;
    return 0;
}

unsigned char I2CRead(unsigned char ack)
{
    unsigned char i, b;

    b = 0x00;
    for(i=0;i<8;i++)
    {
        b <<= 1;
        SCLLOW;
        SCLREL;
        if (P0 & SDA)
            b |= 0x01;
    }
    SCLLOW;
    if (ack)
        SDALOW;
    else
        SDAREL;
    SCLREL;
    while(ISSCLL)
        ;
    SCLLOW;
    SDAREL;
    return b;
}
