/*= i2ctest.c ==================================================================
 *
 * Copyright (C) 2003-2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   This example contains an implementation of I2C routines for the nRF9E5 and
 *   shows how to use them to read the temperature from a Dallas Semiconductor
 *   DS1624 Digital Thermometer and Memory.
 *
 *   The temperature is output to the four LEDs according to this table:
 *
 *                                    LED1 LED2 LED3 LED4
 *               Temp < 24 deg/C:       on  off  off  off
 *   24 deg/C >= Temp < 26 deg/C        on   on  off  off
 *   26 deg/C >= Temp < 28 deg/C        on   on   on  off
 *   28 deg/C >= Temp                   on   on   on   on
 *
 *
 *   The transmitter is selected by conncting the P01 input to GND with a pull-
 *   down resistor and the receiver is selected by connecting P01 to VCC with a
 *   pull-up resistor. The temperature sensor must be connected to the
 *   transmitter. The four switches on S206 must be set to on on the receiver
 *   and off on the transmitter. S205 must be set to off on both boards.
 *
 *   Remember to adjust the constant DS1624_I2C_ADDRESS below if the address of
 *   the DS1624 is not 15. Please see the file i2c.c for a description on how to
 *   connect the I2C data and clock lines.
 *
 *   Please set HFREQ below to a setting that matches the frequency of your
 *   EVBOARD. You also have to set the channel if a frequency other than the
 *   default is needed.
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.07a.
 *
 * $Revision: 3 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>
#include "ds1624.h"

#define HFREQ 0                     // 0=433MHz, 1=868/915MHz
#define POWER 3                     // 0=min power...3 = max power

#define DS1624_I2C_ADDRESS 0x0F

void Delay100us(volatile unsigned char n)
{
    unsigned char i;
    while(n--)
        for(i=0;i<35;i++)
            ;
}

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                  // Clear SPI interrupt
    SPI_DATA = b;                   // Move byte to send to SPI data register
    while((EXIF & 0x20) == 0x00)    // Wait until SPI hs finished transmitting
        ;
    return SPI_DATA;
}

void Led(unsigned char n, unsigned char on)
{
    switch (n)
    {
        case 0:
            P00 = (on)? 0:1;
            break;

        case 1:
            P02 = (on)? 0:1;
            break;

        case 2:
            P04 = (on)? 0:1;
            break;

        case 3:
            P06 = (on)? 0:1;
            break;
    }
}

unsigned char ReceivePacket()
{
    unsigned char b;

    TRX_CE = 1;

    while(DR == 0)
        ;
    RACSN = 0;
    SpiReadWrite(RRP);
    b = SpiReadWrite(0);
    RACSN = 1;
    TRX_CE = 0;
    return b;
}

void TransmitPacket(unsigned char b)
{
    RACSN = 0;
    SpiReadWrite(WTP);
    SpiReadWrite(b);
    RACSN = 1;
    TRX_CE = 1;
    Delay100us(1);
    TRX_CE = 0;
}

void LedTemp(unsigned char temp)
{
    if (temp < 24)
    {
        Led(0, 1);
        Led(1, 0);
        Led(2, 0);
        Led(3, 0);
    } else if (temp < 26)
    {
        Led(0, 1);
        Led(1, 1);
        Led(2, 0);
        Led(3, 0);
    } else if (temp < 28)
    {
        Led(0, 1);
        Led(1, 1);
        Led(2, 1);
        Led(3, 0);
    } else
    {
        Led(0, 1);
        Led(1, 1);
        Led(2, 1);
        Led(3, 1);
    }
}

void Receiver(void)
{
    unsigned char b;
    TXEN = 0;
    for(;;)
    {
        b = ReceivePacket();
        LedTemp(b);
    }
}

void Transmitter(void)
{
    unsigned int temp;
    
    DS1624Init();
    TXEN = 1;
    for(;;)
    {
        temp = DS1624ReadTemperature(DS1624_I2C_ADDRESS)>>8;
        TransmitPacket((unsigned char)temp);
        LedTemp((unsigned char)temp);
    }
}

void Init(void)
{
    unsigned char tmp;

    P0_DIR &= ~0x5d;                // P00, P02, P03, P04 and P06 are outputs
    P0_DIR |= 0x02;                 // P01 is input
    P0 &= ~0x08;                    // Provide a 0 on P03 for the rec/tran selection
    
    SPICLK = 0;                     // Max SPI clock
    SPI_CTRL = 0x02;                // Connect internal SPI controller to Radio

    // Configure Radio:
    RACSN = 0;
    SpiReadWrite(WRC | 0x03);       // Write to RF config address 3 (RX payload)
    SpiReadWrite(0x01);             // One byte RX payload
    SpiReadWrite(0x01);             // One byte TX payload
    RACSN = 1;

    RACSN = 0;
    SpiReadWrite(CC | 0x0f);        // Max power, HFREQ_PLL=1
    SpiReadWrite(0x5f);
    RACSN = 1;

    TXEN = 0;
    TRX_CE = 0;

    // Switch to 16MHz clock:
    RACSN = 0;
    SpiReadWrite(RRC | 0x09);
    tmp = SpiReadWrite(0) | 0x04;
    RACSN = 1;
    RACSN = 0;
    SpiReadWrite(WRC | 0x09);
    SpiReadWrite(tmp); 
    RACSN = 1;

    // Configure output power and RF frequency band:
    RACSN = 0;
    SpiReadWrite(RRC | 0x01);       // Read RF config address 1
    tmp = SpiReadWrite(0) & 0xf1;   // Clear the power and frequency setting bits
    RACSN = 1;

    RACSN = 0;
    SpiReadWrite(WRC | 0x01);      // Write RF config address 1
    // Change power defined by POWER and to 433MHz or 868/915MHz defined by HFREQ above:
    SpiReadWrite(tmp | (POWER <<2) | (HFREQ << 1));
    RACSN = 1;
}

void main(void)
{
    Init();
    if (P01 == 1)
    {
        Receiver();
    } else
    {
        Transmitter();
    }
}
