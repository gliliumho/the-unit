/*= ds1624.c ===================================================================
 *
 * Copyright (C) 2003-2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   Routine to read the temperature from a Dallas Semiconductor DS1624
 *   Digital Thermometer and Memory.
 *
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.07a.
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>
#include "i2c.h"
#include "ds1624.h"

#define ACCESS_MEM      0x17
#define ACCESS_CONF     0xAC
#define READ_TEMP       0xAA
#define START_CONVERT   0xEE
#define STOP_CONVERT    0x22

#define READ            0x01
#define WRITE           0x00

void DS1624Init(void)
{
    I2CInit();
}

unsigned int DS1624ReadTemperature(unsigned char addr)
{
    unsigned int temp;

    I2CStart();
    I2CWrite(0x90 | (addr<<1) | WRITE);
    I2CWrite(START_CONVERT);
    while(1)
    {
        I2CRepStart();
        I2CWrite(0x90 | (addr<<1) | WRITE);
        I2CWrite(ACCESS_CONF);
        I2CRepStart();
        I2CWrite(0x90 | (addr<<1) | READ);
        if (I2CRead(0) & 0x80)
            break;
    }
    I2CRepStart();
    I2CWrite(0x90 | (addr<<1) | WRITE);
    I2CWrite(READ_TEMP);
    I2CRepStart();
    I2CWrite(0x90 | (addr<<1) | READ);
    temp = (unsigned int)I2CRead(1);
    temp <<= 8;
    temp |= (unsigned int)I2CRead(0);
    I2CStop();
    return temp;
}
