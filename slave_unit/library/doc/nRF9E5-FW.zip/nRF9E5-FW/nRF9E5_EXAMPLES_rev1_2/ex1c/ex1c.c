/*= ex1c.c =====================================================================
 * 
 * Copyright (C) 2003, 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *   Hello World program. Please note that this program runs the internal 8051
 *   on the default power up frequency of 4MHz. See ex3c.c for an example on how
 *   to switch to 16MHz.
 *
 *   The functionality is the same as in ex1a.asm.
 *
 * COMPILER:
 *
 *  This program has been tested with Keil V7.07a.
 *
 * $Revision: 3 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>

void Init(void)
{
    TH1 = 243;          // 4800@4MHz (when T1M=1 and SMOD=1)
    CKCON |= 0x10;      // T1M=1 (/4 timer clock)
    PCON = 0x80;        // SMOD=1 (double baud rate)
    SCON = 0x52;        // Serial mode1, enable receiver
    TMOD = 0x20;        // Timer1 8bit auto reload 
    TR1 = 1;            // Start timer1
    P0_ALT |= 0x06;     // Select alternate functions on pins P0.1 and P0.2
    P0_DIR |= 0x02;     // P0.1 (RxD) is input
}

void PutChar(char c)
{
    while(!TI)
        ;
    TI = 0;
    SBUF = c;
}

void PutString(const char *s)
{
    while(*s != 0)
        PutChar(*s++);
}

int main(void)
{
    Init();
    PutString("Hello World!\n");
    for (;;)
        ;
    return 0;
}
