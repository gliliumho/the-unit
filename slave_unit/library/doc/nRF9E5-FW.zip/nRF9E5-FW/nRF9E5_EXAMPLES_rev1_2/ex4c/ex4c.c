/*= ex4c.c =====================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION:
 *
 *  This example shows how to read the LM35 temperature sensor on the EVBOARD and
 *  output the value in hexadecimal form to the serial port.
 *
 * COMPILER:
 *
 *  This program has been tested with Keil V7.07a.
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include <Nordic\reg9e5.h>

const char hex_tab[] = "0123456789ABCDEF";

void Delay100us(volatile unsigned char n)
{
    unsigned char i;
    while(n--)
        for(i=0;i<35;i++)
            ;
}

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                  // Clear SPI interrupt
    SPI_DATA = b;                   // Move byte to send to SPI data register
    while((EXIF & 0x20) == 0x00)    // Wait until SPI hs finished transmitting
        ;
    return SPI_DATA;
}

void InitADC(void)
{
    // Configure and turn on ADC
    RACSN = 0;
    SpiReadWrite(WAC);              // Write to ADC config
    SpiReadWrite(0x35);             // Select AIN3, PWR_UP = 1, VFSEL=0;
    SpiReadWrite(0x0b);             // Set RES_CTRL = 3, Right justified
    RACSN = 1;
}

void Init(void)
{
    unsigned char cklf;

    TH1 = 243;                      // 19200@16MHz (when T1M=1 and SMOD=1)
    CKCON |= 0x10;                  // T1M=1 (/4 timer clock)
    PCON = 0x80;                    // SMOD=1 (double baud rate)
    SCON = 0x52;                    // Serial mode1, enable receiver
    TMOD = 0x20;                    // Timer1 8bit auto reload 
    TR1 = 1;                        // Start timer1
    P0_ALT |= 0x06;                 // Select alternate functions on pins P0.1 and P0.2
    P0_DIR |= 0x02;                 // P0.1 (RxD) is input

    SPICLK = 0;                     // Max SPI clock
    SPI_CTRL = 0x02;                // Connect internal SPI controller to Radio

    // Switch to 16MHz clock:
    RACSN = 0;
    SpiReadWrite(RRC | 0x09);
    cklf = SpiReadWrite(0) | 0x04;
    RACSN = 1;
    RACSN = 0;
    SpiReadWrite(WRC | 0x09);
    SpiReadWrite(cklf); 
    RACSN = 1;
    InitADC();
}

void PutChar(char c)
{
    while(!TI)
        ;
    TI = 0;
    SBUF = c;
}

void PutString(const char *s)
{
    while(*s != 0)
        PutChar(*s++);
}

void HexOutNib(unsigned char n)
{
    PutChar(hex_tab[n & 0x0f]);
}

void HexOutByte(unsigned char b)
{
    HexOutNib(b >> 4);
    HexOutNib(b & 0x0f);
}

void main(void)
{
    unsigned char adc0, adc1, i;
    Init();
    for (;;)
    {
        // Start ADC conversion
        RACSN = 0;
        SpiReadWrite(SAV  | 0x03);
        RACSN = 1;

        // Wait until ADC conversion completes
        while(EOC == 0)
            ;
        // Read Out ADC Value
        RACSN = 0;
        SpiReadWrite(RAD);
        adc0 = SpiReadWrite(NOP);
        adc1 = SpiReadWrite(NOP);
        RACSN = 1;
        HexOutByte(adc1);
        HexOutByte(adc0);
        PutString("\r\n");
        // Wait a while
        for (i=0;i<10;i++)
            Delay100us(255);
    }
}
