/*= nrfexx.h ===================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 3 $
 *
 *==============================================================================
*/
#ifndef __EEWRITE_NRFEXX_H__
#define __EEWRITE_NRFEXX_H__

// Please select the device you are using by commenting/uncommenting the appropriate
// line below:
//#define nRF9E5 1
#define nRF24E1 1

#ifdef nRF9E5
#include <Nordic\reg9e5.h>
#else
#include <Nordic\reg24e1.h>
sbit EECSN = P0^0;
#endif

void NrfInit(void);

#endif
