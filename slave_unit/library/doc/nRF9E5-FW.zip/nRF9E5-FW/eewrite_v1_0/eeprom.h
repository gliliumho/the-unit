/*= eeprom.h ===================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#ifndef __EEWRITE_EEPROM_H__
#define __EEWRITE_EEPROM_H__

void EEInit(void);
unsigned char EEStatus(void);
unsigned char EERead(unsigned int addr);
void EEWrite(unsigned int addr, unsigned char b);

#endif
