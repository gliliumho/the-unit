/*= util.h =====================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#ifndef __EEWRITE_UTIL_H__
#define __EEWRITE_UTIL_H__

unsigned char SpiReadWrite(unsigned char b);
void PutString(const char *s);
void HexOutNib(unsigned char n);
void HexOutByte(unsigned char b);
void HexOutWord(unsigned int w);
unsigned char HexInNib(void);
unsigned char HexInByte(void);
unsigned int HexInWord(void);

#endif
