This folder contains functions for reading and writing the EEPROM connected to
the nRF24E1 or nRF9E5.

To try out the test program program your eval board with one of the precompiled
hex-files, connect the eval board to the serial port of your computer and start
up a terminal emulator in 19200 baud. Hit 'r' in the terminal window to read a
byte from the EEPROM and 'w' to write a byte.

It is assumed that the EEPROM is not write protected. If parts or whole of the
EEPROM is protected you must pull the /WP pin high to make sure writing is
possible.

Please also read the description in the header of "main.c" and "nrfexx.h".
