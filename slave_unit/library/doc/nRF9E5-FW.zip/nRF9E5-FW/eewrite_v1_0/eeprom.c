/*= eeprom.c ===================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.09
 *
 * $Revision: 3 $
 *
 *==============================================================================
*/
#include "nrfexx.h"
#include "util.h"
#include "eeprom.h"

#define EE_WRSR     0x01
#define EE_WRITE    0x02
#define EE_READ     0x03
#define EE_WRDI     0x04
#define EE_RDSR     0x05
#define EE_WREN     0x06

void EEInit(void)
{
#ifdef nRF9E5
//  P1_DIR &= ~0x1b;
    SPICLK = 5;                             // CLK/32 SPI clock
#else
    P0_DIR &= ~0x01;                        // EECSN is output
    SPICLK = 2;                             // CLK/32 SPI clock
#endif
    EECSN = 1;
    SPI_CTRL = 0x01;                        // Connect internal SPI to P1
}

unsigned char EEStatus(void)
{
    unsigned char b;

    EECSN = 0;
    SpiReadWrite(EE_RDSR);
    b = SpiReadWrite(0);
    EECSN = 1;
    return b;
}

unsigned char EERead(unsigned int addr)
{
    unsigned char b;

    while ((EEStatus() & 0x01) != 0x00)     // Wait if busy
        ;
    EECSN = 0;
    SpiReadWrite(EE_READ);
    SpiReadWrite(addr >> 8);
    SpiReadWrite(addr & 0xff);
    b = SpiReadWrite(0);
    EECSN = 1;
    return b;
}

void EEWrite(unsigned int addr, unsigned char b)
{
    while((EEStatus() & 0x01) != 0x00)      // Wait if busy
        ;
    EECSN = 0;
    SpiReadWrite(EE_WREN);
    EECSN = 1;
    EECSN = 0;
    SpiReadWrite(EE_WRITE);
    SpiReadWrite(addr >> 8);
    SpiReadWrite(addr & 0xff);
    SpiReadWrite(b);
    EECSN = 1;
}
