/*= uart.h =====================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#ifndef __EEWRITE_UART_H__
#define __EEWRITE_UART_H__

void UartInit(void);
void PutChar(char c);
char GetChar(void);

#endif
