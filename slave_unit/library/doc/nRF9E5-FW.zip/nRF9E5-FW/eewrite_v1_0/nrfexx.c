/*= nrfexx.c ===================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.09
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include "nrfexx.h"
#include "util.h"

void NrfInit(void)
{
#ifdef nRF9E5
    unsigned char cklf;

    SPICLK = 0;                             // Max SPI clock
    SPI_CTRL = 0x02;                        // Connect SPI controller to Radio

    // switch to 16MHz clock:
    RACSN = 0;
    SpiReadWrite(RRC | 0x09);
    cklf = SpiReadWrite(0) | 0x04;
    RACSN = 1;
    RACSN = 0;
    SpiReadWrite(WRC | 0x09);
    SpiReadWrite(cklf); 
    RACSN = 1;
#endif
}
