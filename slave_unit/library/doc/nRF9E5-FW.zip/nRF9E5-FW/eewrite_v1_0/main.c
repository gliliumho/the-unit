/*==============================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * DESCRIPTION
 *
 *   EEPROM reading and writing test program. To use test this program connect
 *   a nRF24E1 or nRF9E5 evaluation board to the serial port of your computer
 *   and start up a terminal emulator in 19200 baud. Hit 'r' in the terminal
 *   window to read a byte from the EEPROM and 'w' to write a byte. Please also
 *   read the description in the header of "eeprom.c".
 *
 *   NOTE: This source code is compatible with both nRF9E5 and nRF24E1. Please
 *         select the device you are using by uncommenting/commenting the
 *         appropriate line at the top of "nrfexx.h".
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.09
 *
 * $Revision: 3 $
 *
 *==============================================================================
*/
#include "nrfexx.h"
#include "eeprom.h"
#include "util.h"
#include "uart.h"

void Init(void)
{
    UartInit();
    NrfInit();
    EEInit();
}

void main(void)
{
    unsigned int a;
    unsigned char b;

    Init();
    while(1)
    {
        switch(GetChar())
        {
            case 'r':
            case 'R':
                PutString("Read EEPROM byte\r\n");
                PutString("Address (4 hex-digits): ");
                a = HexInWord();
                b = EERead(a);
                PutString("\r\nThe byte at address 0x");
                HexOutWord(a);
                PutString(" is 0x");
                HexOutByte(b);
                PutString("\r\n");
                break;

            case 'w':
            case 'W':
                PutString("Write EEPROM byte\r\n");
                PutString("Address (4 hex-digits): ");
                a = HexInWord();
                PutString("\r\nValue (2 hex-digits): ");
                b = HexInByte();
                EEWrite(a, b);
                PutString("\r\n");
                break;

            default:
                PutString("Accepted commands:\r\n");
                PutString("R: Read a byte from the EEPROM\r\n");
                PutString("W: Write a byte to the EEPROM\r\n");
                break;
        }
    }
}
