/*= util.c =====================================================================
 *
 * Copyright (C) 2004 Nordic Semiconductor
 *
 * This file is distributed in the hope that it will be useful, but WITHOUT
 * WARRANTY OF ANY KIND.
 *
 * Author(s): Ole Saether
 *
 * COMPILER:
 *
 *   This program has been tested with Keil C51 V7.09
 *
 * $Revision: 2 $
 *
 *==============================================================================
*/
#include "nrfexx.h"
#include "util.h"
#include "uart.h"

const char hex_tab[] = "0123456789ABCDEF";      // ASCII-hex table

unsigned char SpiReadWrite(unsigned char b)
{
    EXIF &= ~0x20;                              // Clear SPI interrupt
    SPI_DATA = b;                               // Byte to send to SPI data reg
    while((EXIF & 0x20) == 0x00)                // Wait until SPI is finished
        ;
    return SPI_DATA;
}

void PutString(const char *s)
{
    while(*s != 0)
        PutChar(*s++);
}

void HexOutNib(unsigned char n)
{
    PutChar(hex_tab[n & 0x0f]);
}

void HexOutByte(unsigned char b)
{
    HexOutNib(b >> 4);
    HexOutNib(b & 0x0f);
}

void HexOutWord(unsigned int w)
{
    HexOutByte(w >> 8);
    HexOutByte(w & 0xff);
}

unsigned char HexInNib(void)
{
    unsigned char c;
    c = GetChar();
    if (c >= '0' && c <= '9')
        return c - '0';
    else if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    else 
        return c - 'A' + 10;
}

unsigned char HexInByte(void)
{
    char nh = HexInNib();
    return (nh << 4) | HexInNib();
}

unsigned int HexInWord(void)
{
    unsigned int bh = HexInByte();
    return (bh << 8) | HexInByte();
}
